# kahoot-flooder
Flood Kahoot games with bots and scare your teachers. This software can send ~2000 bots to a Kahoot game. It is easy to use and doesn't need any installing. The bots can be normal or smart, normal - bots will do nothing, just join, smart - bots will answer questions randomly (max 200 bots will answer because Kahoot has DDOS protection)

download here:
https://github.com/gnelis-cyber/kahoot-flooder/raw/master/flooder-win.zip

<h2>Quick Start Guide</h2>

 Uzip the file, open the program (`flooder-win.exe`)
 , Folow the instructions in the program to use it ;)
